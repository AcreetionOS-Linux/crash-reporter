#ifndef CONFIG_H
#define CONFIG_H

#define GITHUB_TOKEN "your_github_token_here"
#define GEMINI_API_KEY "your_gemini_api_key_here"

#define GITHUB_REPO_OWNER "acreetionos-linux"
#define GITHUB_REPO_NAME "acreetionos"

// Comma-separated usernames to ping, e.g., "cobra3282000,spivajohnathan64"
#define GITHUB_PING_USERS "cobra3282000,spivajohnathan64"

#endif // CONFIG_H
