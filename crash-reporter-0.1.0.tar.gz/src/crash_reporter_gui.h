#ifndef CRASH_REPORTER_GUI_H
#define CRASH_REPORTER_GUI_H

#include "crash_reporter.h" // For SystemInfo struct and other declarations

void create_and_show_gui(int argc, char *argv[], SystemInfo* info);

#endif // CRASH_REPORTER_GUI_H