# crash-reporter
A utility pulling crash logs and other information user information for assistance with debugging.
